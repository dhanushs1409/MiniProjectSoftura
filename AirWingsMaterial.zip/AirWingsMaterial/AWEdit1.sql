use AirWings
go

select * from Passenger
--verification

--block1
alter table Payments 
drop constraint FK_PNo

drop table Passenger

alter table Passenger
drop constraint CK_validemail

alter table Passenger
drop constraint CK_passwordlength
--passenger table was created again with phno as datatype bigint, and validation being moved to Controller

--block2
alter table Payments
add constraint FK_PNo foreign key (pno) references Passenger(pno)

alter table FlightDetails
drop constraint FK_FlightID

alter table Flights 
drop constraint PK_FlightId

alter table Flights
drop column bookingid

alter table Payments
drop column bookingid

alter table Flights
add bookingid int identity(678,12)

alter table Payments
add bookingid int

alter table Flights
add constraint PK_BookingId primary key (bookingid)
--logic being refined, bookingid being incremented by 12 to not be easily predictable

--block3
alter table Payments
add nooftxn int identity(1,1)

alter table Payments
add constraint PK_NoOfTxn primary key (nooftxn)
--number of transactions stored for refinement

drop table CityCodes
--refining logic

create table AvailableFlights
(
	dep varchar(20),
	arr varchar(20),
	traveldate date,
	flighttime time,
	flightid int identity(1,1)
)

select * from AvailableFlights

alter table Flights
alter column dep varchar(30)

alter table Flights
alter column arr varchar(30)

alter table AvailableFlights
alter column dep varchar(30)

alter table AvailableFlights
alter column arr varchar(30)

alter table AvailableFlights
add depcode varchar(3)

alter table AvailableFlights
add arrcode varchar(3)

select * from AvailableFlights

alter table AvailableFlights
add constraint PK_FlightID primary key (flightid)

--now values will be inserted to be displayed as selection
insert into AvailableFlights
values('Chennai', 'Bangalore', '2022-10-20', '12:00:00', 'MAA', 'BLR')

insert into AvailableFlights
values('Bangalore', 'Chennai', '2022-10-20', '12:00:00', 'BLR', 'MAA')

insert into AvailableFlights
values('Chennai', 'Madurai', '2022-10-20', '10:00:00', 'MAA', 'IXM')

insert into AvailableFlights
values('Madurai', 'Chennai', '2022-10-20', '11:00:00', 'IXM', 'MAA')

insert into AvailableFlights
values('Madurai', 'Bangalore', '2022-10-20', '12:00:00', 'IXM', 'BLR')

insert into AvailableFlights
values('Bangalore', 'Madurai', '2022-10-20', '12:00:00', 'BLR', 'IXM')

--this is a long line of text to differentiate
insert into AvailableFlights
values('Chennai', 'Bangalore', '2022-10-20', '20:00:00', 'MAA', 'BLR')

insert into AvailableFlights
values('Bangalore', 'Chennai', '2022-10-20', '19:00:00', 'BLR', 'MAA')

insert into AvailableFlights
values('Chennai', 'Madurai', '2022-10-20', '18:00:00', 'MAA', 'IXM')

insert into AvailableFlights
values('Madurai', 'Chennai', '2022-10-20', '17:00:00', 'IXM', 'MAA')

insert into AvailableFlights
values('Madurai', 'Bangalore', '2022-10-20', '21:00:00', 'IXM', 'BLR')

insert into AvailableFlights
values('Bangalore', 'Madurai', '2022-10-20', '22:00:00', 'BLR', 'IXM')

select * from Flights

select * from Payments

delete from Flights
where flightid=0