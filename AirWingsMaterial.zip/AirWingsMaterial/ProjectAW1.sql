use AirWings
go

create table Passenger
(	pno int identity(101,1),
	fname varchar(20) not null,
	lname varchar(20),
	username varchar(30) not null unique,
	email varchar(30) not null, 
	phno bigint,
	dob date not null,
	gender varchar(1),
	password varchar(30) not null,
	constraint CK_passwordlength check ((len(password)>=8)),
	constraint CK_validemail check (email like '%__@__%.__%'),
	constraint PK_PNo primary key (pno)
)

create table Flights
(
	dep varchar(20),
	arr varchar(20),
	traveldate date,
	flighttime time,
	flightid int,
	depcode varchar(3),
	arrcode varchar(3),
	pno int,
	ticketqty int,
	price float,
	cnf bit,
	bookingid int,
	constraint PK_FlightId primary key (flightid),
	constraint FK_BookingID foreign key (bookingid) references Payments (bookingid)

)
create table CityCodes
(
	city varchar(20),
	citycode varchar(3),
	constraint PK_City_Code primary key (citycode)
)
create table FlightDetails
(
	maxseats int,
	flightid int,
	flightcompany varchar(25),
	depcode varchar(3),
	arrcode varchar(3),
	availableseats int,
	seatno int,
	constraint PK_AvailableSeats primary key (availableseats),
	constraint FK_FlightID foreign key (flightid) references Flights (flightid)
)
create table Payments
(
	cardno bigint,
	expdate date,
	pno int,
	cvv int,
	bookingid int identity(1001, 1),
	constraint FK_PNo foreign key (pno) references Passenger(pno),
	constraint PK_BookingID primary key (bookingid)
)
create table PassengerChart
(
	pno int,
	seatno int identity(1,1),
	fname varchar(20),
	constraint PK_SeatNo primary key (seatno)
)
